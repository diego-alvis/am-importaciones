<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Setting;
use App\Models\Location;
use App\Models\Stand;
use App\Models\Category;
use App\Models\Product;
use App\Models\Stock;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        Setting::insert([
            ['key' => 'viatico_diario', 'value' => '11.00', 'description' => 'Monto fijo de viáticos'],
            ['key' => 'meta_comision', 'value' => '400.00', 'description' => 'Meta para ganar comisión'],
            ['key' => 'bono_comision', 'value' => '10.00', 'description' => 'Bono por meta alcanzada'],
        ]);

        $location = Location::create([
            'name' => 'Almacén Central',
            'type' => 'almacen',
        ]);

        $stand = Stand::create([
            'location_id' => $location->id,
            'name' => 'Stand Principal',
            'base_cash' => 0.00,
        ]);

        User::create([
            'name' => 'Diego',
            'email' => 'admin@amimportaciones.com',
            'password' => Hash::make('password123'),
            'role' => 'admin',
            'location_id' => $location->id,
            'stand_id' => $stand->id,
        ]);

        $catCarcasas = Category::create(['name' => 'Carcasas']);
        $catCargadores = Category::create(['name' => 'Cargadores']);

        $prod1 = Product::create([
            'category_id' => $catCarcasas->id,
            'sku' => 'SKU-1001',
            'name' => 'Funda Silicona Antigolpes',
            'base_price' => 15.00,
        ]);

        $prod2 = Product::create([
            'category_id' => $catCargadores->id,
            'sku' => 'SKU-1002',
            'name' => 'Cargador Rápido 20W Tipo C',
            'base_price' => 35.00,
        ]);

        Stock::create([
            'product_id' => $prod1->id,
            'location_id' => $location->id,
            'quantity' => 45,
        ]);

        Stock::create([
            'product_id' => $prod2->id,
            'location_id' => $location->id,
            'quantity' => 12,
        ]);
    }
}