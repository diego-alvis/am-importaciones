<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->enum('role', ['admin', 'almacenero', 'encargado', 'vendedor'])->default('vendedor')->after('password');
            $table->foreignId('location_id')->nullable()->constrained()->nullOnDelete()->after('role');
            $table->foreignId('stand_id')->nullable()->constrained()->nullOnDelete()->after('location_id');
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            //
        });
    }
};
