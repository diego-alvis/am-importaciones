<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CashSession;

class CashController extends Controller
{
    public function index()
    {
        $activeSession = CashSession::where('user_id', auth()->id())
                                    ->where('status', 'open')
                                    ->first();

        return view('cash.index', compact('activeSession'));
    }

    public function open(Request $request)
    {
        $request->validate(['opening_amount' => 'required|numeric|min:0']);

        CashSession::create([
            'user_id' => auth()->id(),
            'stand_id' => auth()->user()->stand_id,
            'opening_amount' => $request->opening_amount,
            'opened_at' => now(),
            'status' => 'open',
        ]);

        return redirect()->route('cash.index');
    }
}
