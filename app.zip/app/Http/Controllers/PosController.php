<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\Stock;

class PosController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        $products = Product::with(['category', 'stocks' => function($query) {
            $query->where('location_id', 1);
        }])->get();

        return view('pos.index', compact('products', 'categories'));
    }
    public function store(Request $request)
    {
        DB::beginTransaction();

        try {
            $sale = Sale::create([
                'cash_session_id' => 1, 
                'user_id' => auth()->id(),
                'total_amount' => $request->total,
                'status' => 'completed',
            ]);

            foreach ($request->cart as $item) {
                SaleItem::create([
                    'sale_id' => $sale->id,
                    'product_id' => $item['id'],
                    'quantity' => $item['quantity'],
                    'price' => $item['price'],
                ]);

                Stock::where('product_id', $item['id'])
                     ->where('location_id', auth()->user()->location_id)
                     ->decrement('quantity', $item['quantity']);
            }

            DB::commit();
            return response()->json(['success' => true]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }
}