<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-2xl text-gray-800 leading-tight flex items-center gap-2">
            <svg class="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
            {{ __('Resumen General - A y M Importaciones') }}
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-8">
            
            <!-- TARJETAS DE MÉTRICAS (KPIs) -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                
                <!-- Ventas de Hoy -->
                <div class="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl shadow-lg p-6 text-white relative overflow-hidden">
                    <div class="relative z-10">
                        <p class="text-green-100 text-sm font-bold uppercase tracking-wider mb-1">Mis Ventas (Hoy)</p>
                        <h3 class="text-3xl font-black">S/ {{ number_format($ventasHoy, 2) }}</h3>
                    </div>
                    <svg class="w-24 h-24 text-green-400 absolute -bottom-4 -right-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
                </div>

                <!-- Estado de Caja -->
                <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-lg p-6 text-white relative overflow-hidden">
                    <div class="relative z-10">
                        <p class="text-blue-100 text-sm font-bold uppercase tracking-wider mb-1">Estado de Turno</p>
                        @if($cajaActiva)
                            <h3 class="text-2xl font-black flex items-center gap-2">
                                <span class="w-3 h-3 rounded-full bg-green-300 animate-pulse"></span> Caja Abierta
                            </h3>
                            
                            @if(auth()->user()->isAdmin())
                                <p class="text-xs text-blue-100 mt-1">{{ $cajaActiva }} caja(s) activa(s) globalmente</p>
                            @else
                                <p class="text-xs text-blue-100 mt-1">Sede: {{ $cajaActiva->stand->name ?? 'Asignada' }}</p>
                            @endif

                        @else
                            <h3 class="text-2xl font-black text-gray-200">Caja Cerrada</h3>
                            <p class="text-xs text-blue-100 mt-1">Requiere apertura para operar</p>
                        @endif
                    </div>
                    <svg class="w-24 h-24 text-blue-400 absolute -bottom-4 -right-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>

                <!-- Alerta de Stock -->
                <div class="bg-gradient-to-br from-red-500 to-red-600 rounded-2xl shadow-lg p-6 text-white relative overflow-hidden">
                    <div class="relative z-10">
                        <p class="text-red-100 text-sm font-bold uppercase tracking-wider mb-1">Alertas de Stock</p>
                        <h3 class="text-3xl font-black">{{ $bajoStock }} <span class="text-lg font-normal">productos</span></h3>
                    </div>
                    <svg class="w-24 h-24 text-red-400 absolute -bottom-4 -right-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                </div>

                <!-- Total Productos -->
                <div class="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl shadow-lg p-6 text-white relative overflow-hidden">
                    <div class="relative z-10">
                        <p class="text-purple-100 text-sm font-bold uppercase tracking-wider mb-1">Catálogo Activo</p>
                        <h3 class="text-3xl font-black">{{ $totalProductos }} <span class="text-lg font-normal">ítems</span></h3>
                    </div>
                    <svg class="w-24 h-24 text-purple-400 absolute -bottom-4 -right-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                <!-- ACCESOS RÁPIDOS -->
                <div class="lg:col-span-1 space-y-4">
                    <h3 class="text-lg font-black text-gray-800 border-b pb-2">Accesos Principales</h3>
                    
                    <a href="{{ route('pos.index') }}" class="group block bg-white rounded-xl shadow-sm border border-gray-200 p-4 hover:border-blue-500 hover:shadow-md transition">
                        <div class="flex items-center gap-4">
                            <div class="bg-blue-100 text-blue-600 p-3 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-900 group-hover:text-blue-600 transition">Punto de Venta (POS)</h4>
                                <p class="text-sm text-gray-500">Registrar nuevas ventas</p>
                            </div>
                        </div>
                    </a>

                    <a href="{{ route('cash_registers.index') }}" class="group block bg-white rounded-xl shadow-sm border border-gray-200 p-4 hover:border-green-500 hover:shadow-md transition">
                        <div class="flex items-center gap-4">
                            <div class="bg-green-100 text-green-600 p-3 rounded-lg group-hover:bg-green-600 group-hover:text-white transition">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-900 group-hover:text-green-600 transition">Arqueo de Caja</h4>
                                <p class="text-sm text-gray-500">Gestión de turno e ingresos</p>
                            </div>
                        </div>
                    </a>

                    <a href="{{ route('inventory.index') }}" class="group block bg-white rounded-xl shadow-sm border border-gray-200 p-4 hover:border-purple-500 hover:shadow-md transition">
                        <div class="flex items-center gap-4">
                            <div class="bg-purple-100 text-purple-600 p-3 rounded-lg group-hover:bg-purple-600 group-hover:text-white transition">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-900 group-hover:text-purple-600 transition">Inventario</h4>
                                <p class="text-sm text-gray-500">Control de stock y productos</p>
                            </div>
                        </div>
                    </a>
                </div>

                <!-- ACTIVIDAD RECIENTE -->
                <div class="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex flex-col">
                    <div class="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                        <h3 class="text-lg font-black text-gray-800">Últimas 5 Transacciones</h3>
                        <a href="{{ route('history.index') }}" class="text-sm font-bold text-blue-600 hover:text-blue-800">Ver todo el historial &rarr;</a>
                    </div>
                    
                    <div class="overflow-x-auto flex-1">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="text-gray-400 uppercase text-xs tracking-wider border-b">
                                    <th class="p-4 font-semibold">Recibo</th>
                                    <th class="p-4 font-semibold">Hora</th>
                                    <th class="p-4 font-semibold">Sede</th>
                                    <th class="p-4 font-semibold text-center">Método</th>
                                    <th class="p-4 font-semibold text-right">Total</th>
                                </tr>
                            </thead>
                            <tbody class="text-sm text-gray-600 divide-y divide-gray-50">
                                @forelse($ultimasVentas as $venta)
                                    <tr class="hover:bg-gray-50 transition">
                                        <td class="p-4 font-mono font-bold text-gray-900">{{ $venta->receipt_number }}</td>
                                        <td class="p-4 text-gray-500">{{ $venta->created_at->format('h:i A') }}</td>
                                        <td class="p-4 text-xs font-semibold">{{ $venta->stand->name ?? 'N/A' }}</td>
                                        <td class="p-4 text-center">
                                            @php
                                                $color = match($venta->payment_method) {
                                                    'yape' => 'bg-purple-100 text-purple-700',
                                                    'plin' => 'bg-teal-100 text-teal-700',
                                                    'tarjeta' => 'bg-gray-800 text-white',
                                                    default => 'bg-green-100 text-green-700',
                                                };
                                            @endphp
                                            <span class="px-2 py-1 rounded-md text-xs font-bold {{ $color }}">
                                                {{ ucfirst($venta->payment_method) }}
                                            </span>
                                        </td>
                                        <td class="p-4 text-right font-black text-gray-900">S/ {{ number_format($venta->total_amount, 2) }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="p-8 text-center text-gray-400">
                                            Aún no has registrado ventas el día de hoy.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</x-app-layout>