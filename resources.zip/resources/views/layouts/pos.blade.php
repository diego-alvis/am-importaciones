<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>POS - A y M Importaciones</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-slate-50 flex h-screen overflow-hidden font-sans text-slate-800">
    <aside class="w-20 lg:w-64 bg-slate-900 text-slate-300 flex flex-col transition-all duration-300">
        <div class="h-16 flex items-center justify-center border-b border-slate-800 bg-slate-950">
            <span class="text-white font-bold text-xl hidden lg:block tracking-wider">A y M <span class="text-blue-500">POS</span></span>
            <span class="text-white font-bold text-xl lg:hidden text-blue-500">POS</span>
        </div>
        <nav class="flex-1 px-3 py-6 space-y-3">
            <a href="{{ route('pos.index') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-blue-600 text-white shadow-md">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                <span class="hidden lg:block font-medium">Punto de Venta</span>
            </a>
            <a href="{{ route('cash.index') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-800 hover:text-white transition-colors">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                <span class="hidden lg:block font-medium">Caja y Finanzas</span>
            </a>
        </nav>
    </aside>

    <div class="flex-1 flex flex-col h-screen">
        <header class="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0">
            <div class="flex items-center gap-4">
                <span class="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-md text-xs font-bold border border-emerald-200 flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Turno Activo
                </span>
                <span class="text-slate-500 text-sm hidden md:block">Sede: <strong class="text-slate-700">Almacén Central</strong></span>
            </div>
            <div class="flex items-center gap-4">
                <span class="text-sm font-semibold text-slate-700">{{ Auth::user()->name ?? 'Admin' }}</span>
                <div class="h-9 w-9 bg-slate-900 text-white rounded-full flex items-center justify-center font-bold shadow-inner">
                    {{ substr(Auth::user()->name ?? 'A', 0, 1) }}
                </div>
            </div>
        </header>
        
        @yield('content')
    </div>
</body>
</html>