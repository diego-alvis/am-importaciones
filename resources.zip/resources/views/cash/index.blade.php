@extends('layouts.pos')

@section('content')
<main class="flex-1 overflow-y-auto p-6 bg-slate-50">
    <div class="max-w-4xl mx-auto">
        
        @if(!$activeSession)
        <!-- Formulario de Apertura -->
        <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 max-w-md mx-auto mt-10">
            <div class="text-center mb-6">
                <div class="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                </div>
                <h2 class="text-xl font-bold text-slate-800">Abrir Turno de Caja</h2>
                <p class="text-sm text-slate-500 mt-1">Ingresa el monto base en efectivo para iniciar las operaciones.</p>
            </div>

            <form action="{{ route('cash.open') }}" method="POST">
                @csrf
                <div class="mb-5">
                    <label class="block text-sm font-bold text-slate-700 mb-2">Monto Inicial (S/)</label>
                    <input type="number" step="0.01" name="opening_amount" required min="0" class="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 font-bold text-lg text-slate-800" placeholder="0.00">
                </div>
                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl shadow-md transition-all text-lg">
                    Confirmar Apertura
                </button>
            </form>
        </div>
        @else
        <!-- Estado de Caja Abierta -->
        <div class="bg-white rounded-2xl shadow-sm border border-emerald-200 p-8 text-center max-w-lg mx-auto mt-10">
            <div class="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            </div>
            <h2 class="text-2xl font-black text-slate-800">Caja Operativa</h2>
            <p class="text-slate-600 font-medium mt-2">Tu turno está abierto y listo para registrar ventas.</p>
            
            <div class="mt-6 bg-slate-50 p-4 rounded-xl border border-slate-100 flex justify-between items-center">
                <span class="text-sm font-bold text-slate-500 uppercase tracking-wide">Fondo Inicial</span>
                <span class="text-xl font-black text-emerald-600">S/ {{ number_format($activeSession->opening_amount, 2) }}</span>
            </div>

            <div class="mt-6 flex gap-3">
                <a href="{{ route('pos.index') }}" class="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl transition-all block content-center">Ir al POS</a>
                <button class="flex-1 bg-red-50 hover:bg-red-100 text-red-600 font-bold py-3 rounded-xl transition-all border border-red-200 opacity-50 cursor-not-allowed" disabled>Cerrar Turno</button>
            </div>
        </div>
        @endif

    </div>
</main>
@endsection