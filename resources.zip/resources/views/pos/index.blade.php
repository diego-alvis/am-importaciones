@extends('layouts.pos')

@section('content')
<main class="flex-1 flex flex-col lg:flex-row overflow-hidden p-4 gap-4" x-data="posSystem()" x-cloak>
    <!-- Catálogo -->
    <section class="flex-1 flex flex-col min-w-0 bg-white rounded-xl shadow-sm border border-slate-200">
        <div class="p-4 border-b border-slate-100 flex gap-3 bg-slate-50 rounded-t-xl">
            <div class="relative flex-1">
                <svg class="w-5 h-5 absolute left-3 top-2.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                <input type="text" x-model="search" placeholder="Código SKU o Nombre..." class="w-full pl-10 pr-4 py-2.5 text-sm rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-shadow">
            </div>
            <select x-model="category" class="px-4 py-2.5 text-sm rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-white font-medium text-slate-600 hidden sm:block">
                <option value="">Todas las categorías</option>
                @foreach($categories as $cat)
                    <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                @endforeach
            </select>
        </div>
        
        <div class="flex-1 overflow-y-auto p-4">
            <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                @forelse($products as $product)
                <div x-show="matchesSearch('{{ $product->name }}', '{{ $product->sku }}', '{{ $product->category_id }}')" 
                     x-on:click="addToCart({ id: {{ $product->id }}, name: '{{ addslashes($product->name) }}', price: {{ $product->base_price }} })"
                     class="border border-slate-200 rounded-xl p-3 hover:border-blue-500 hover:shadow-md transition-all cursor-pointer group bg-white">
                    <div class="text-[11px] text-slate-400 font-mono mb-1">{{ $product->sku }}</div>
                    <h3 class="font-bold text-sm text-slate-800 leading-tight h-10 line-clamp-2">{{ $product->name }}</h3>
                    <div class="mt-2 flex justify-between items-center">
                        <span class="font-extrabold text-blue-600">S/ {{ number_format($product->base_price, 2) }}</span>
                        <span class="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded font-bold">
                            {{ $product->stocks->first()->quantity ?? 0 }} und
                        </span>
                    </div>
                </div>
                @empty
                <div class="col-span-full text-center text-slate-500 py-10 font-medium">
                    No hay productos registrados en el catálogo.
                </div>
                @endforelse
            </div>
        </div>
    </section>

    <!-- Ticket -->
    <aside class="w-full lg:w-[420px] bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col shrink-0 relative">
        <div class="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50 rounded-t-xl">
            <h2 class="font-extrabold text-slate-800 flex items-center gap-2">
                <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path></svg>
                Ticket de Venta
            </h2>
            <button x-on:click="emptyCart()" x-show="cart.length > 0" class="text-red-500 hover:bg-red-50 px-2 py-1 rounded text-xs font-bold transition-colors">VACIAR</button>
        </div>
        
        <div class="flex-1 overflow-y-auto p-2">
            <div x-show="cart.length === 0" class="text-center text-slate-400 text-sm mt-10 font-medium">
                Selecciona productos del catálogo para agregarlos al ticket.
            </div>

            <template x-for="(item, index) in cart" :key="index">
                <div class="p-3 bg-white border border-slate-100 rounded-lg shadow-sm mb-2 relative group">
                    <button x-on:click="removeFromCart(index)" class="absolute -right-2 -top-2 bg-red-100 text-red-600 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold opacity-0 group-hover:opacity-100 transition-opacity">✕</button>
                    <div class="flex justify-between items-start mb-2">
                        <span class="font-bold text-sm text-slate-800 w-3/4 leading-tight" x-text="item.name"></span>
                        <span class="font-extrabold text-sm text-slate-800" x-text="'S/ ' + (item.price * item.quantity).toFixed(2)"></span>
                    </div>
                    <div class="flex justify-between items-center mt-3">
                        <input type="text" x-model="item.device_model" placeholder="Modelo (Ej. iPhone 13)" class="text-xs px-2.5 py-1.5 border border-blue-200 bg-blue-50 rounded-md w-32 focus:outline-none focus:ring-1 focus:ring-blue-500 text-blue-900 placeholder-blue-400 font-medium">
                        <div class="flex items-center gap-1 bg-slate-100 rounded-md border border-slate-200">
                            <button x-on:click="updateQuantity(index, -1)" class="w-8 h-7 text-slate-600 hover:bg-slate-200 rounded-l-md font-bold transition-colors">-</button>
                            <span class="w-6 text-center text-sm font-bold text-slate-800" x-text="item.quantity"></span>
                            <button x-on:click="updateQuantity(index, 1)" class="w-8 h-7 text-slate-600 hover:bg-slate-200 rounded-r-md font-bold transition-colors">+</button>
                        </div>
                    </div>
                </div>
            </template>
        </div>

        <div class="p-4 bg-slate-50 border-t border-slate-200 rounded-b-xl">
            <div class="flex justify-between items-center mb-4">
                <span class="text-slate-600 font-bold uppercase text-xs tracking-wider">Total a cobrar</span>
                <span class="text-3xl font-black text-blue-600" x-text="'S/ ' + total.toFixed(2)"></span>
            </div>
            
            <div class="grid grid-cols-3 gap-2 mb-2">
                <button @click="processDirectPayment('Efectivo')" :disabled="cart.length === 0" :class="{'opacity-50 cursor-not-allowed': cart.length === 0}" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-lg shadow-sm transition-all flex flex-col items-center justify-center text-sm">
                    Efectivo
                </button>
                <button @click="processDirectPayment('Yape/Plin')" :disabled="cart.length === 0" :class="{'opacity-50 cursor-not-allowed': cart.length === 0}" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-lg shadow-sm transition-all flex flex-col items-center justify-center text-sm">
                    Yape/Plin
                </button>
                <button @click="processDirectPayment('Tarjeta')" :disabled="cart.length === 0" :class="{'opacity-50 cursor-not-allowed': cart.length === 0}" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg shadow-sm transition-all flex flex-col items-center justify-center text-sm">
                    Tarjeta
                </button>
            </div>

            <button x-on:click="showCheckout = true" :disabled="cart.length === 0" :class="{'opacity-50 cursor-not-allowed': cart.length === 0}" class="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold py-2.5 rounded-lg shadow-sm transition-all flex justify-center items-center gap-2 text-sm mt-2">
                Dividir Pago / Calcular Vuelto
            </button>
        </div>
    </aside>

    <!-- Modal de Cobro (Pagos Mixtos) -->
    <div x-show="showCheckout" class="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center" style="display: none;">
        <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden" @click.away="showCheckout = false">
            <div class="p-5 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                <h3 class="font-bold text-lg text-slate-800">Dividir Pago / Vuelto</h3>
                <button @click="showCheckout = false" class="text-slate-400 hover:text-red-500 font-bold text-xl">&times;</button>
            </div>
            
            <div class="p-6 space-y-4">
                <div class="flex justify-between items-center bg-blue-50 p-4 rounded-xl border border-blue-100">
                    <span class="font-bold text-blue-800">Total a Pagar</span>
                    <span class="font-black text-2xl text-blue-600" x-text="'S/ ' + total.toFixed(2)"></span>
                </div>

                <div class="space-y-3">
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-1">Efectivo (S/)</label>
                        <input type="number" x-model.number="payCash" class="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 font-bold text-lg text-slate-800" placeholder="0.00">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-1">Yape / Plin (S/)</label>
                        <input type="number" x-model.number="payTransfer" class="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 font-bold text-lg text-slate-800" placeholder="0.00">
                    </div>
                </div>

                <div class="flex justify-between items-center p-4 rounded-xl border" :class="change >= 0 ? 'bg-green-50 border-green-100' : 'bg-red-50 border-red-100'">
                    <span class="font-bold" :class="change >= 0 ? 'text-green-800' : 'text-red-800'">Vuelto / Faltante</span>
                    <span class="font-black text-xl" :class="change >= 0 ? 'text-green-600' : 'text-red-600'" x-text="'S/ ' + Math.abs(change).toFixed(2)"></span>
                </div>
            </div>

            <div class="p-5 border-t border-slate-100 bg-slate-50">
                <button @click="confirmSale()" :disabled="change < 0" :class="{'opacity-50 cursor-not-allowed': change < 0}" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl shadow-md transition-all text-lg">
                    Confirmar Venta
                </button>
            </div>
        </div>
    </div>
</main>

<script>
function posSystem() {
    return {
        search: '',
        category: '',
        cart: [],
        showCheckout: false,
        payCash: 0,
        payTransfer: 0,
        
        get total() {
            return this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        },

        get change() {
            return (Number(this.payCash) + Number(this.payTransfer)) - this.total;
        },
        
        matchesSearch(name, sku, categoryId) {
            const matchesText = name.toLowerCase().includes(this.search.toLowerCase()) || sku.toLowerCase().includes(this.search.toLowerCase());
            const matchesCategory = this.category === '' || categoryId.toString() === this.category;
            return matchesText && matchesCategory;
        },
        
        addToCart(product) {
            let existingItem = this.cart.find(i => i.id === product.id);
            if (existingItem) {
                existingItem.quantity++;
            } else {
                this.cart.push({ id: product.id, name: product.name, price: parseFloat(product.price), quantity: 1, device_model: '' });
            }
        },
        
        removeFromCart(index) { this.cart.splice(index, 1); },
        updateQuantity(index, delta) { this.cart[index].quantity + delta > 0 ? this.cart[index].quantity += delta : this.removeFromCart(index); },
        emptyCart() { this.cart = []; },

        async submitToServer(method, cash, transfer, changeValue) {
            try {
                const response = await fetch('/pos/sale', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify({
                        cart: this.cart, total: this.total, payment_method: method,
                        cash_tendered: cash, transfer_tendered: transfer, change: changeValue
                    })
                });
                
                const data = await response.json();
                if(data.success) {
                    window.location.reload(); // Recarga para actualizar el stock visualmente
                } else {
                    alert('Error en el servidor: ' + data.error);
                }
            } catch (error) {
                alert('Fallo de conexión.');
            }
        },

        processDirectPayment(method) {
            if (this.cart.length === 0) return;
            this.submitToServer(method, this.total, 0, 0);
        },

        confirmSale() {
            if (this.change < 0) return;
            this.submitToServer('Mixto', this.payCash, this.payTransfer, this.change);
        }
    }
}
</script>
@endsection