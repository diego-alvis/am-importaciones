<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PosController;

Route::get('/', function () {
    return redirect()->route('pos.index');
});

Route::middleware(['auth'])->group(function () {
    

    Route::get('/pos', [PosController::class, 'index'])->name('pos.index');
    Route::get('/dashboard', function () {
        return redirect()->route('pos.index');
    })->name('dashboard');
    Route::post('/pos/sale', [PosController::class, 'store'])->name('pos.store');
    Route::get('/caja', [App\Http\Controllers\CashController::class, 'index'])->name('cash.index');
    Route::post('/caja/abrir', [App\Http\Controllers\CashController::class, 'open'])->name('cash.open');
    
});

require __DIR__.'/auth.php';